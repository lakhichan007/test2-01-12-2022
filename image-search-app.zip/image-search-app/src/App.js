import Page from "./components/page";

function App() {
  return (
   <>
   <Page/>
   </>
  );
}

export default App;
